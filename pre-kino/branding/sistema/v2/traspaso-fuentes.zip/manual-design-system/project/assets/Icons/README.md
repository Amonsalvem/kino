# Icons

Nueve iconos de **Iconoir** (licencia MIT), elegidos para el recorrido del invitado. Retícula de 24 × 24, trazo de 1,5.

Aquí se muestran en `kino-sustrato-700` (`#618174`), que se lee sobre fondo claro y oscuro. En código se usa el original de `iconoir` (`npm i iconoir`) con `stroke="currentColor"`, teñido desde el token de texto de su contexto.

| Archivo | Para qué |
|---|---|
| `home-simple.svg` | Casa o unidad del residente |
| `user.svg` | Persona con pase: invitado o colaborador |
| `car.svg` | Ingreso por placa |
| `qr-code.svg` | Ingreso por QR |
| `key.svg` | Código de un solo uso |
| `calendar.svg` | Vigencia por días |
| `clock.svg` | Vigencia por horas y franjas |
| `bell.svg` | Aviso de «por vencer» |
| `warning-triangle.svg` | Alerta o error del sistema |

Reglas:

- El icono nunca reemplaza la palabra en un estado.
- La gota de la marca es el único símbolo que marca un ingreso en la traza.
- Sin candados ni escudos. Por eso `shield-alert` salió de la selección.
